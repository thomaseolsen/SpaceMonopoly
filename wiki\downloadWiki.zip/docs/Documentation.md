Documentation for playing the game is currently at: [http://space.monopoly.iwarp.com/](http://space.monopoly.iwarp.com/)

To compile the project:

# Download the source code
# Download Borland C++ Builder 3 (other versions will probably work too).  There is a version available at: [http://bcb-tools.com/Downloads.htm](http://bcb-tools.com/Downloads.htm)
# Install C++ Builder
# Open the project file "SpacePoly2.mak" in c++ builder 
# Do a "Project Build" in C++ builder

The above will make the SpacePoly2.exe file.


