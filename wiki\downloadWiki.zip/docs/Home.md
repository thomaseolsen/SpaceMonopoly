**Project Description**
Space monopoly is the freeware game of buying and selling shares.


